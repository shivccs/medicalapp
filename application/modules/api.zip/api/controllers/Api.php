<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends MX_Controller {

	function __construct() 
		{
			Parent::__construct();
			$this->load->model('auth_model');
			$this->load->module('template');
			$this->load->library('session');
		}
	public function index()
	{	
		
			
	}


	function affilate_doctorlogin(){
		    $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			
			  
		     $email=$taskdata['email'];
			 $phone=$taskdata['phone'];
			
			
   
        if(empty($taskdata['email'])){
            $response['error_code']="1";
			$response['response_string']="Failed";
			$response['data']="";
        }
        else if(empty($taskdata['phone'])){
            $response['error_code']="1";
			$response['response_string']="Failed";
			$response['data']="";
        }
        else{
    		$email=$taskdata['email'];
    		$password=$taskdata['phone'];
    
    		$response['error_code']="1";
    		
            
			
    		$count=$this->auth_model->count_row_multiple('email',$email,'phone',$password,'users');
			
			if($count>=1)
			{
				$data=$this->auth_model->get_specific_data('email',$email,'users');
				$lastcount=$this->auth_model->get_x('login_count','email',$email,'users');
				
				if($lastcount==0)
				{
					date_default_timezone_set("Asia/Kolkata");
					$date=date("d-m-y h:i:s");
					$data1=array(
					'last_login'=>$date,
					'login_count'=>1,
					'is_active'=>1,
					);
					$this->auth_model->edit_data('email',$email,$data1,'users');
				}
				else{
					$l1=$lastcount+1;
					date_default_timezone_set("Asia/Kolkata");
					$date=date("d-m-y h:i:s");
					$data1=array(
					'last_login'=>$date,
					'login_count'=>$l1,
					'is_active'=>1,
					);
					$this->auth_model->edit_data('email',$email,$data1,'users');
				}
				print_r($data);
				   $response['error_code']="0";
			         $response['response_string']="User Found";
			         $response['userdata']=$data;
					  
			
			}
			else{
				$response['error_code']="1";
			     $response['response_string']="No User Found";
			      $response['id']="";
				
			}
    			
    				
    			
    		
        }

		header('Content-Type: application/json');
		echo json_encode($response);

	}
	
	
	function affilate_doctor_profile()
{
	            $this->load->model('auth_model');
		       $taskdata = json_decode(file_get_contents('php://input'),true);
			   $temp_doc_id=$taskdata['doctor_id'];
		
			   
			    // $data=$this->auth_model->get_specific_data('doctor_id',$doctor_id,'doctors');
			  $data = $this->auth_model->get_affilate_profile($temp_doc_id);
			   
			   
			
			if($data)
			{
				
				$response['error_code']="0";
			$response['response_string']="Doctor Found";
			$response['doctorRecord']=$data;
			
			}
			else{
				$response['error_code']="1";
			$response['response_string']="No Doctor Found";
			$response['doctorRecord']='';
				
			}
			   
			   header('Content-Type: application/json');
		       echo json_encode($response);
			   
}


function register_patient()
{
	            $this->load->model('auth_model');
		       $taskdata = json_decode(file_get_contents('php://input'),true);
			   $name=$taskdata['name'];
		       $email=$taskdata['email'];
			   $phone=$taskdata['phone'];
			   $dob=$taskdata['dob'];
			   $gender=$taskdata['gender'];  

			   $maritial_status=$taskdata['maritial_status'];
			   $height=$taskdata['height'];
			   $weight=$taskdata['weight'];
			   $blood_group=$taskdata['blood_group']; 

			   $address=$taskdata['address'];
			   $city=$taskdata['city'];
			   $state=$taskdata['state'];
			   $latitude=$taskdata['latitude']; 
			    $long=$taskdata['longitude']; 
			    $doctor_id=$taskdata['doctor_id']; 

			$count=$this->auth_model->count_patient($email,$phone);
			 if($count>=1)
			 {
                    $response['error_code']="1";
			       $response['response_string']="Email & Phone Number Already Exsist";
			
			 }
            else
             {
                    $data=array(
				'patient_name' => $name,
               'phone_number' => $phone,
               'email'=>$email,
               'dob'=>$dob,
               'gender'=>$gender,
               'maritial_status'=>$maritial_status,
               'height'=>$height,
               'weight'=>$weight,
               'blood_group'=>$blood_group,
               'address'=>$address,
               'city'=>$city,
               'lat'=>$latitude,
               'longitude'=>$long,
               'state'=>$state,
               'created_by'=>$doctor_id,
               'created_on'=>date('Y-m-d'),
               'status'=>1,
			    );

                    	$ins=$this->auth_model->insert_data('patients',$data);
                    	if($ins)
                    	{
                            $response['error_code']="0";
			                $response['response_string']="Data Saved";
			                $response['Patient_id']=$ins;

                    	}
                    	else
                    	{
                    		 $response['error_code']="1";
			                $response['response_string']="Eror Data Saved";
                    	}

             }

       header('Content-Type: application/json');
		echo json_encode($response);



}
function update_affilate()
{
	            $this->load->model('auth_model');
		       $taskdata = json_decode(file_get_contents('php://input'),true);
			   $first=$taskdata['first_name'];
		       $middle=$taskdata['middle_name'];
			   $last=$taskdata['last_name'];  
               $pwd=$taskdata['pwd'];
			   
			   $father=$taskdata['father'];
			   $gender=$taskdata['gender'];
			   $dob=$taskdata['dob']; 
			 
			    $address=$taskdata['address'];
			   $city=$taskdata['city'];
			   $state=$taskdata['state'];
			   $latitude=$taskdata['latitude']; 
			    $long=$taskdata['longitude']; 
			    $doctor_id=$taskdata['doctor_id']; 

			
			 
                    $data=array(
				  'first_name' => $first,
                 'middle_name'=>$middle,
                 'last_name'=>$last,
                 'pwd'=>$pwd
               
			    );
				
				$data1=array(
				'father_name'=>$father,
				'gender'=>$gender,
				'dob'=>$dob,
				'address'=>$address,
                'city'=>$city,
               'latitude'=>$latitude,
               'longitude'=>$long,
               'state'=>$state
               
				);
				
				

                    	$ins=$this->auth_model->edit_data('user_id',$doctor_id,$data,'users');
						$ins1=$this->auth_model->edit_data('user_id',$doctor_id,$data1,'user_info');
                    	if($ins1)
                    	{
                            $response['error_code']="0";
			                $response['response_string']="Data Updated Successfully";
			                

                    	}
                    	else
                    	{
                    		 $response['error_code']="1";
			                $response['response_string']="Eror In Updation Saved";
                    	}

             

       header('Content-Type: application/json');
		echo json_encode($response);



}


function update_patient()
{
	            $this->load->model('auth_model');
		       $taskdata = json_decode(file_get_contents('php://input'),true);
			   $name=$taskdata['name'];
		       $dob=$taskdata['dob'];
			   $gender=$taskdata['gender'];  

			   $maritial_status=$taskdata['maritial_status'];
			   $height=$taskdata['height'];
			   $weight=$taskdata['weight'];
			   $blood_group=$taskdata['blood_group']; 

			   $address=$taskdata['address'];
			   $city=$taskdata['city'];
			   $state=$taskdata['state'];
			   $latitude=$taskdata['latitude']; 
			    $long=$taskdata['longitude']; 
			    $patient_id=$taskdata['patient_id']; 

			
			 
                    $data=array(
				'patient_name' => $name,
                'dob'=>$dob,
               'gender'=>$gender,
               'maritial_status'=>$maritial_status,
               'height'=>$height,
               'weight'=>$weight,
               'blood_group'=>$blood_group,
               'address'=>$address,
               'city'=>$city,
               'lat'=>$latitude,
               'longitude'=>$long,
               'state'=>$state,
               
			    );

                    	$ins=$this->auth_model->edit_data('patient_id ',$patient_id,$data,'patients');
                    	if($ins)
                    	{
                            $response['error_code']="0";
			                $response['response_string']="Data Updated Successfully";
			                

                    	}
                    	else
                    	{
                    		 $response['error_code']="1";
			                $response['response_string']="Eror In Updation Saved";
                    	}

             

       header('Content-Type: application/json');
		echo json_encode($response);



}

function add_doctor_aviability()
{
	            $this->load->model('auth_model');
		       $taskdata = json_decode(file_get_contents('php://input'),true);
			   $doctor_id=$taskdata['doctor_id'];
		       $day=$taskdata['day'];
			   $start=$taskdata['start'];  

			   $end=$taskdata['end'];
			  

			
			 
                    $data=array(
				'doctor_id' => $doctor_id,
                'day'=>$day,
               'start'=>$start,
               'end'=>$end
               
			    );

                    	$ins=$this->auth_model->insert_data('doctor_aviability ',$data);
                    	if($ins)
                    	{
                            $response['error_code']="0";
			                $response['response_string']="Doctor Aviability Added";
							 $response['aviability_id']=$ins;
			                

                    	}
                    	else
                    	{
                    		 $response['error_code']="1";
			                $response['response_string']="Eror In Doctor Aviability Saved";
                    	}

             

       header('Content-Type: application/json');
		echo json_encode($response);



}

function update_doctor_aviability()
{
	            $this->load->model('auth_model');
		       $taskdata = json_decode(file_get_contents('php://input'),true);
			   $aviable_id=$taskdata['aviability_id'];
		       $day=$taskdata['day'];
			   $start=$taskdata['start'];  

			   $end=$taskdata['end'];
			  

			
			 
                    $data=array(
				'day'=>$day,
               'start'=>$start,
               'end'=>$end
               
			    );

                    	$ins=$this->auth_model->edit_data('id ',$aviable_id,$data,'doctor_aviability');
                    	if($ins)
                    	{
                            $response['error_code']="0";
			                $response['response_string']="Doctor Updated ";
							
			                

                    	}
                    	else
                    	{
                    		 $response['error_code']="1";
			                $response['response_string']="Eror In Doctor Update";
                    	}

             

       header('Content-Type: application/json');
		echo json_encode($response);



}

function patient_profile()
{
	            $this->load->model('auth_model');
		       $taskdata = json_decode(file_get_contents('php://input'),true);
			   $patient_id=$taskdata['patient_id'];
			   $data=$this->auth_model->get_specific_data('patient_id',$patient_id,'patients');
			
			if($data)
			{
				
				$response['error_code']="0";
			$response['response_string']="Patient Found";
			$response['doctorRecord']=$data;
			
			}
			else{
				$response['error_code']="1";
			$response['response_string']="No Patient Found";
			$response['doctorRecord']='';
				
			}
			   
			   header('Content-Type: application/json');
		echo json_encode($response);
			   
}

function doctor_profile()
{
	            $this->load->model('auth_model');
		       $taskdata = json_decode(file_get_contents('php://input'),true);
			   $temp_doc_id=$taskdata['doctor_id'];
		
			   
			    // $data=$this->auth_model->get_specific_data('doctor_id',$doctor_id,'doctors');
			  $data = $this->auth_model->getdoctorprofile($temp_doc_id);
			   print_r($data);
			   
			
			if($data)
			{
				
				$response['error_code']="0";
			$response['response_string']="Doctor Found";
			$response['doctorRecord']=$data;
			
			}
			else{
				$response['error_code']="1";
			$response['response_string']="No Doctor Found";
			$response['doctorRecord']='';
				
			}
			   
			   header('Content-Type: application/json');
		       echo json_encode($response);
			   
}


	function doctorlogin(){
		    $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			
			  
		     $email=$taskdata['email'];
			 $phone=$taskdata['phone'];
			
			
   
        if(empty($taskdata['email'])){
            $response['error_code']="1";
			$response['response_string']="Failed";
			$response['data']="";
        }
        else if(empty($taskdata['phone'])){
            $response['error_code']="1";
			$response['response_string']="Failed";
			$response['data']="";
        }
        else{
    		$email=$taskdata['email'];
    		$password=$taskdata['phone'];
    
    		$response['error_code']="1";
    		
            
			
    		$count=$this->auth_model->count_row_multiple('email',$email,'phone',$password,'doctors');
			
			if($count>=1)
			{
				$data=$this->auth_model->get_specific_data('email',$email,'doctors');
				$response['error_code']="0";
			$response['response_string']="Doctor Found";
			$response['userdata']=$data;
			
			}
			else{
				$response['error_code']="1";
			$response['response_string']="No Doctor Found";
			$response['id']="";
				
			}
    			
    				
    			
    		
        }

		header('Content-Type: application/json');
		echo json_encode($response);

	}
	function get_allergies_list(){
		  $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			$status=1;
			$data = $this->auth_model->get_specific_data('Status', $status,'allergies');
			if(!empty($data))
			{
				$response['error_code']="0";
			    $response['response_string']="Allergy Found";
			     $response['data']=$data;
			}
			else{
				$response['error_code']="1";
			    $response['response_string']="No Allergy Found";
			     $response['data']="";
			}
			 header('Content-Type: application/json');
		     echo json_encode($response);
		
		
	}
	
	function get_disease_list(){
		  $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			$status=1;
			$data = $this->auth_model->get_specific_data('Status', $status,'disease');
			if(!empty($data))
			{
				$response['error_code']="0";
			    $response['response_string']="Disease Found";
			     $response['data']=$data;
			}
			else{
				$response['error_code']="1";
			    $response['response_string']="No Disease Found";
			     $response['data']="";
			}
			 header('Content-Type: application/json');
		     echo json_encode($response);
		
		
	}
	function get_surgery_list(){
		  $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			$status=1;
			$data = $this->auth_model->get_specific_data('Status', $status,'surgeries');
			if(!empty($data))
			{
				$response['error_code']="0";
			    $response['response_string']="Surgery Found";
			     $response['data']=$data;
			}
			else{
				$response['error_code']="1";
			    $response['response_string']="No Surgery Found";
			     $response['data']="";
			}
			 header('Content-Type: application/json');
		     echo json_encode($response);
		
		
	}
	
	function doctor_aviability(){
		  $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			$temp_doc_id=$taskdata['doctor_id'];
			$data = $this->auth_model->get_specific_data('doctor_id', $temp_doc_id,'doctor_aviability');
			if(!empty($data))
			{
				$response['error_code']="0";
			    $response['response_string']="Doctor Found";
			     $response['data']=$data;
			}
			else{
				$response['error_code']="1";
			    $response['response_string']="No Doctor Found";
			     $response['data']="";
			}
			 header('Content-Type: application/json');
		     echo json_encode($response);
		
		
	}
	
	function patient_doctor_aviability(){
		  $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
		
			 $latitude=$taskdata['latitude'];
			  $longitude=$taskdata['longitude'];
			//$latitude   =28.5355;
			//$longitude= 77.3910;
			date_default_timezone_set("Asia/Kolkata");
           $created_at =  Date('Y-m-d');
		   $day = date('l', strtotime($created_at));
			$data = $this->auth_model->getRawResult("SELECT *, (((acos(sin((".$latitude."*pi()/180)) * sin((`latitude`*pi()/180)) + cos((".$latitude."*pi()/180)) * cos((`latitude`*pi()/180)) * cos(((".$longitude."- `longitude`)*pi()/180)))) * 180/pi()) * 60 * 1.1515) as distance FROM `doctor_info`,doctor_aviability where doctor_aviability.day='$day' and doctor_info.doctor_id=doctor_aviability.doctor_id and CURTIME() >= doctor_aviability.start AND CURTIME() < doctor_aviability.end order by distance asc");
			if($data)
			{
				$response['error_code']="0";
			    $response['response_string']="Doctor Found";
			     $response['data']=$data;
			}
			else{
				$response['error_code']="1";
			    $response['response_string']="No Doctor Found";
			     $response['data']="";
			}
		
		header('Content-Type: application/json');
		     echo json_encode($response);
		
	}
	function doctor_profile_edit(){
		    $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			$this->load->library('form_validation');
			
		$doctor_id			=		$this->input->post('doctorid');
	    $fname 			=		$this->input->post('fname');
		$lname 			=		$this->input->post('lname');
		$fathername		=		$this->input->post('fathername');
		$gender 		=		$this->input->post('gender');
		
		$dob 			=		$this->input->post('dob');
		$category 		=		$this->input->post('category');
		$address		=		$this->input->post('address');
		$state			=		$this->input->post('state');
		$city			=		$this->input->post('city');
		$pincode		=		$this->input->post('pincode');
		$lat 			=		$this->input->post('lat');
		$long 			=		$this->input->post('long');


		$registration_no		=		$this->input->post('registration_no');
		$mc						=		$this->input->post('mc');
		$mc_year				=		$this->input->post('mc_year');
		$md						=		$this->input->post('md');
		$md_year 				=		$this->input->post('md_year');
		$md_college 			=		$this->input->post('md_college');
		$experience 			=		$this->input->post('experience');

		$specility 				=		$this->input->post('specility');
			$this->form_validation->set_rules('doctorid', 'Doctorid', 'required'); 
			$this->form_validation->set_rules('fname', 'Fname', 'required'); 
			$this->form_validation->set_rules('lname', 'Lname', 'required'); 
			$this->form_validation->set_rules('fathername', 'Fathername', 'required'); 
			
			$this->form_validation->set_rules('gender', 'Gender', 'required'); 
			$this->form_validation->set_rules('dob', 'Dob', 'required'); 
			$this->form_validation->set_rules('category', 'Category', 'required'); 
			$this->form_validation->set_rules('address', 'Address', 'required');
			
			$this->form_validation->set_rules('state', 'State', 'required'); 
			$this->form_validation->set_rules('city', 'City', 'required'); 
			$this->form_validation->set_rules('pincode', 'Pincode', 'required'); 
			$this->form_validation->set_rules('lat', 'Lat', 'required');
			$this->form_validation->set_rules('long', 'Long', 'required');
			
			$this->form_validation->set_rules('registration_no', 'Registration_no', 'required'); 
			$this->form_validation->set_rules('mc', 'Mc', 'required'); 
			$this->form_validation->set_rules('mc_year', 'Mc_Year', 'required'); 
			$this->form_validation->set_rules('md', 'Md', 'required');
			$this->form_validation->set_rules('md_year', 'Md_year', 'required');
			$this->form_validation->set_rules('md_college', 'Md_college', 'required');
			$this->form_validation->set_rules('experience', 'Experience', 'required');
			
			if ($this->form_validation->run() == FALSE) { 
            // $this->load->view('myform'); 
			//echo "fail";
			 $response['error_code']="1";
			$response['response_string']="All Fields Are Not Filled";
			$response['data']="";
             } 
		  else { 
            
			
			$u_data = array(

				'category_id'			=>		$category,
				'speciality_id'			=>		$specility_val,
				'first_name'			=>		$fname,
				'last_name'				=>		$lname
				
				
			);
			


			$ui_data = array(
				'father_name'			=>		$fathername,
				'gender'				=>		$gender,
				'dob'					=>		$dob,
				'address'				=>		$address,
				'state'					=>		$state,
				'city'					=>		$city,
				'pincode'				=>		$pincode,
				'latitude'				=>		$lat,
				'longitude'				=>		$long,
				'added_on'				=>		date('Y-m-d'),
				'added_by' 				=>		$session_user_id
			);

			$uf_data = array(
				'registration_no'		=>		$registration_no,		
				'medical_council'		=>		$mc,
				'certification_year'	=>		$mc_year,
				'medical_degree'		=>		$md,
				'passout_year'			=>		$md_year,
				'college_name'			=>		$md_college,
				'experience' 			=>		$experience,
				'added_on'				=>		date('Y-m-d'),
				'added_by' 				=>		$session_user_id
			);	


			$result = $this->auth_model->edit_user1($u_data, $ui_data, $uf_data,$doctor_id);
			if($result)
			{
				$response['error_code']="0";
			    $response['response_string']="Record Updated Successfully";
			    $response['data']="";
			}
			else{
				$response['error_code']="1";
			    $response['response_string']="Eror In Updation";
			    $response['data']="";
			}
         } 
		 
        header('Content-Type: application/json');
		echo json_encode($response);


	}
	
	function doctor_appointment(){
		    $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			$doctor_id=$taskdata['doctor_id'];
			$patient_id=$taskdata['patient_id'];
			$date=$taskdata['date'];
			$time=$taskdata['time'];
			$status=$taskdata['status'];
		  
            
			
			$data = array(

				'doctor_id'			=>		$doctor_id,
				'patient_id'			=>		$patient_id,
				'date'			=>		$date,
				'time'				=>		$time,
				'status'   => $status
				
				
			);
			



			$result = $this->auth_model->insert_data('doctor_appointment', $data);
			if($result)
			{
				$response['error_code']="0";
			    $response['response_string']="Appointmaent Added Successfully";
			    $response['Appointment_Id']=$result;
			}
			else{
				$response['error_code']="1";
			    $response['response_string']="Eror In Adding Appointment";
			    $response['data']="";
			}
         
		 
        header('Content-Type: application/json');
		echo json_encode($response);


	}
	
	function add_patient_symptoms(){
		    $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			
			
		   $symptoms=$taskdata['symptoms'];
		   $patient_id=$taskdata['patient_id'];
		 $sym=(explode(',',$symptoms));
		 $rs = $this->auth_model->delete_data('patient_id', $patient_id,'patient_symptom');
		foreach($sym as $rs)
		{ 
		$data = array(

				'symptom_id'			=>		$rs,
				'patient_id'			=>		$patient_id
				
				
				
			);
			



			$result = $this->auth_model->insert_data('patient_symptom', $data);
		
		
		}
		
				$response['error_code']="0";
			    $response['response_string']="Patient Symptom Added";
			    $response['data']="";
			
         
		 
        header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	function add_patient_allergy(){
		    $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			
			
		   $allergy=$taskdata['allergy'];
		   $patient_id=$taskdata['patient_id'];
		 $sym=(explode(',',$allergy));
		 $rs = $this->auth_model->delete_data('patient_id', $patient_id,'patient_allergy');
		foreach($sym as $rs)
		{ 
		$data = array(

				'allergy_id'			=>		$rs,
				'patient_id'			=>		$patient_id
				
				
				
			);
			



			$result = $this->auth_model->insert_data('patient_allergy', $data);
		
		
		}
		
				$response['error_code']="0";
			    $response['response_string']="Patient Allergy Added";
			    $response['data']="";
			
         
		 
        header('Content-Type: application/json');
		echo json_encode($response);
	}

function search_patient(){
		    $this->load->model('auth_model');
		    $taskdata = json_decode(file_get_contents('php://input'),true);
			
			
		   $phone=$taskdata['phone'];
		  

			$result = $this->auth_model->get_specific_data('phone_number', $phone ,'patients');
		
		
		if($result)
		{
		
				$response['error_code']="0";
			    $response['response_string']="Patient Allergy Added";
			    $response['data']=$result;
				
		}
		else{
			$response['error_code']="1";
			    $response['response_string']="No Patient Found";
			    $response['data']="";
		}
			
         
		 
        header('Content-Type: application/json');
		echo json_encode($response);
	}

}//end of class